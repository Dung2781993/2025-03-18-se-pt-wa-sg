// ClinicService.js (updated getPatientAppointments with full patient and appointment info)
const { Appointment, Doctor, Patient } = require("../models");
module.exports = {
  async getPatientAppointments(req, res) {
    try {
      const { id } = req.params;
      console.log("Patient ID:", id);

      if (!id || isNaN(Number(id))) {
        return res.status(400).json({ error: "Valid patient ID is required" });
      }

      const appointments = await Appointment.findAll({
        where: {
          patient_id: id,
          is_deleted: false,
        },
        include: [
          {
            model: Doctor,
            attributes: ["id", "name", "specialty"],
            where: { is_deleted: false },
          },
          {
            model: Patient,
            attributes: ["id", "full_name", "dob", "email", "phone"],
          },
        ],
        attributes: ["id", "scheduled_at", "status", "notes"],
      });

      res.json(appointments);
    } catch (err) {
      res.status(500).json({
        error: "Failed to retrieve patient appointments",
        details: err.message,
      });
    }
  },
};
