const ClinicService = require("../services/ClinicService");

module.exports = {
  getPatientAppointments: (req, res) =>
    ClinicService.getPatientAppointments(req, res),
  // getAppointmentServices: (req, res) =>
  //   ClinicService.getAppointmentServices(req, res),
  // createAppointmentWithServices: (req, res) =>
  //   ClinicService.createAppointmentWithServices(req, res),
  // getInvoiceForAppointment: (req, res) =>
  //   ClinicService.getInvoiceForAppointment(req, res),
  // updateInvoiceStatus: (req, res) =>
  //   ClinicService.updateInvoiceStatus(req, res),
  // createCompleteCheckin: (req, res) =>
  //   ClinicService.createCompleteCheckin(req, res),
  // cancelAppointment: (req, res) => ClinicService.cancelAppointment(req, res),
  // rescheduleAppointment: (req, res) =>
  //   ClinicService.rescheduleAppointment(req, res),
};
