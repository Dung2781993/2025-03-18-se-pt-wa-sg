const express = require("express");
const router = express.Router();
const ClinicController = require("../controllers/ClinicController");

router.get(
  "/patients/:id/appointments",
  ClinicController.getPatientAppointments
);

module.exports = router;
